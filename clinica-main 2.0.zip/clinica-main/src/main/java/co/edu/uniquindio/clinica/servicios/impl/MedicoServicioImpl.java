package co.edu.uniquindio.clinica.servicios.impl;

public class MedicoServicioImpl {
}
