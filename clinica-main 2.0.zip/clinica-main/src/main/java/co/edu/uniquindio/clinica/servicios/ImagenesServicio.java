package co.edu.uniquindio.clinica.servicios;

public interface ImagenesServicio {

    void SubirImagen();
}
