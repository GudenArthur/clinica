package co.edu.uniquindio.clinica.dto;

public record RespuestaPacienteDTO(





) {
}
