package co.edu.uniquindio.clinica.dto;

public record HorarioDTO(String dia,String horaInicio,String horaSalida) {


}
