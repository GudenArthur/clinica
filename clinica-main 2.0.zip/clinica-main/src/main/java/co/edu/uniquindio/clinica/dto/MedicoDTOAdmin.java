package co.edu.uniquindio.clinica.dto;

import co.edu.uniquindio.clinica.modelo.entidades.Especialidad;

public record MedicoDTOAdmin(int codigo, String nombre, String urlFoto, Especialidad especialidad) {



}
