package co.edu.uniquindio.clinica.servicios;

public interface AutenticacionServicio {


    void login();
}
