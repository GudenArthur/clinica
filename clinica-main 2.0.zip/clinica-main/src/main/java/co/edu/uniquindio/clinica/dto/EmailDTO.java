package co.edu.uniquindio.clinica.dto;

public record EmailDTO(String para,String asunto,String mensaje ) {
}
