INSERT INTO cuenta (codigo, correo, password, type_usuario) VALUES (1, 'pepito@email.com', '123', 'tipo_usuario_1');

-- Para el segundo registro
INSERT INTO cuenta (codigo, correo, password, type_usuario) VALUES (2, 'juanita@email.com', '234', 'tipo_usuario_2');
INSERT INTO cuenta (codigo, correo, password, type_usuario) VALUES (3, 'pepito@email.com', '123', 'tipo_usuario_3');

-- Para el segundo registro
INSERT INTO cuenta (codigo, correo, password, type_usuario) VALUES (4, 'juanita@email.com', '234', 'tipo_usuario_4');
INSERT INTO usuario(codigo_ciudad,nombre,telefono,url_foto,codigo)
VALUES ('1','andres','1222233','5666','1');


INSERT INTO usuario(codigo_ciudad,nombre,telefono,url_foto,codigo)
VALUES ('2','garcia','1222333','5667','2');


INSERT INTO medico(codigo,estado,cedula,codigo_especialidad)
VALUES('1','P','45556','1');


INSERT INTO medico(codigo,estado,cedula,codigo_especialidad)
VALUES('2','P','45556','1');



INSERT INTO medico(codigo,estado,cedula,codigo_especialidad)
VALUES('3','P','45556','1');


INSERT INTO medico(codigo,estado,cedula,codigo_especialidad)
VALUES('4','P','45556','1');

